module.exports={
    Api:{
        live:'https://songguolife.com/api/live',activity:'https://songguolife.com/api/activity',
        list:'https://songguolife.com/api/article',
    }
}