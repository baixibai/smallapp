# 微信小程序－💩 滴滴拉屎

### 说明：

实现了查看附近的厕所的功能。

### 数据接口:

- https://api.getweapp.com/vendor/qqmap/search/toilet

### 目录结构：

- pages — 存放项目页面渲染相关文件
- utils — 存放日期格式化文件
- images — 存放图片文件

### 开发环境：

微信web开发者工具 v0.11.122100

### 项目截图：

https://www.getweapp.com/project?projectId=58633ed2e8ff074c22472f85
