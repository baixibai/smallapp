
## 婚礼请柬小程序
基于微信小程序做的一个婚礼请柬

## 有哪些功能？

* 相册展示
* 邀请函展示
* 地图导航
* 好友祝福


## 有问题反馈
在使用中有任何问题，欢迎反馈给我，可以用以下联系方式跟我交流

* 邮件(allen6699#live.cn, 把#换成@)
* QQ: 290805404

### 扫码体验：

<img src="https://wx.qiaker.cn/img/ma.jpg">
Once Love

<img src="https://wx.qiaker.cn/img/ma2.jpg">
Just Married
