exports.app_key = "59ac038ca3648e24ff279a62605b82dd"; //请在此行填写从阿拉丁后台获取的appkey
exports.getLocation = false; //默认不获取用户坐标位置
exports.getUserinfo = false; //默认不获取用户头像昵称
exports.appid = "wxade372ce7f2da061"; //用于用户登录、微信转发群信息、二维码等微信官方功能
exports.appsecret = "e97ae5377cce1748e9b974e20ae7c6da";//用于用户登录、微信转发群信息、二维码等微信官方功能
exports.defaultPath = 'pages/index/index';//小程序的默认首页
