# 微信小程序--装逼生成器
![mahua](http://jsh5css.cn/blog/wp-content/uploads/2017/11/11.gif)
* 感谢[微信小程序|联盟](http://www.wxapp-union.com/) [@amis](http://www.wxapp-union.com/home.php?mod=space&uid=310)提供的素材和创意；  
* 安卓机测试还有问题，还在解决中，
* 原设计稿姓名为黑色字体白色描边效果，由于微信小程序中canvas还没有 `ctx.strokeText()`方法，所以暂时没做描边效果
由于黑色字体不明显，暂时改为灰色字体显示
* 现在开发工具上显示图片，请用手机扫码测试
* 测试有问题请回帖哦，感激！！
