﻿<?php
	
	// 数据库
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASSWORD', 'root');
	define('DB_NAME', 'whisper');
	define('CHARSET', 'utf8');

	// 小程序
	define('APPID', '-');
	define('APPSECRET', '-');

	// 全局变量
	define('SESSIONLIFE', 3600 * 24 * 7);
	define('UPLOADTARGET', '/data/whispers/');
?>