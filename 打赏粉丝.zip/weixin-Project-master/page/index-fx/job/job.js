Page({
	data:{
		san5:"san",
    	follow:[{src:"http://www.tfwk.cn/image/list-img1.png",con:"这个世界上，只有克服了恐惧和别人的眼光，你才能成长 ",xin:"55",comment:"33"}]

	}
})