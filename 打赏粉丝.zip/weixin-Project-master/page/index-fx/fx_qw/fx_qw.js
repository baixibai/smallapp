Page({
	data:{
	 san4:"san",
	 quwei:[{name:"小希",first:"推荐",two:"女神",three:"达人",h1:"今天给大家发福利咯，专业的祛痘小方法，不看会后悔哦！",time:"2016.11.07",xin:"855",yan:"233",src:"http://tfwk.cn/image/photo1.png",con:"http://tfwk.cn/image/fx_tj_img01.png"}]
	}
})