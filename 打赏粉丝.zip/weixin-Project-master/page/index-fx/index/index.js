var app=getApp();
Page({
	onload:function(){

	},
	data:{
		san1:"san",
		list:[{src:"http://tfwk.cn/image/random1.png",h1:"心情好心情坏，每天坚持做运动，啦啦啦，啦啦啦!",like:"54",comment:"58",photo:"http://tfwk.cn/image/photo1.png"},]
	}
})