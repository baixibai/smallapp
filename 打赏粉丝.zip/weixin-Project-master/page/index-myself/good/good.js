Page({
	onLoad:function(){

	},
	data:{
		xiu:[{src:'http://tfwk.cn/image/xiu_img01.jpg',h1:'跟我一起学舞蹈',zan:11,watch:62},
			{src:'http://tfwk.cn/image/xiu_img02.png',h1:'让肌肤更美丽',zan:24,watch:81},
			{src:'http://tfwk.cn/image/xiu_img03.jpg',h1:'个人秀',zan:45,watch:100},
			{src:'http://tfwk.cn/image/xiu_img04.png',h1:'新东方英语',zan:6,watch:30}]
	}
})