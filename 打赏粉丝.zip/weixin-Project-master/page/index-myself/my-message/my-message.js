Page({
	data:{
		mes:[{src:"http://tfwk.cn/image/message-img01.png",small:"21分钟前",con:"尊敬的星咖秀达人您好，您发布的秀已经通过审核了，点击我的秀去看看吧！"},
		     {src:"http://tfwk.cn/image/message-img01.png",small:"58分钟前",con:"您的秀有新的互动评论，点击我的秀去评论区回复吧！"}]
	}
})