Page({
	onLoad:function(){

	},
	data:{
		xiu:[{src:'http://tfwk.cn/image/xiu_img01.jpg',h1:'猛戳我哦~',zan:11,watch:52},
			{src:'http://tfwk.cn/image/xiu_img02.png',h1:'面膜',zan:9,watch:19},
			{src:'http://tfwk.cn/image/xiu_img03.jpg',h1:'跟我来',zan:14,watch:66},
			{src:'http://tfwk.cn/image/xiu_img04.png',h1:'一起学英语',zan:61,watch:123}]
	}
})