Page({
 data: {
    array: [{
      message: '排名'
    }, {
      message: '头像'
    },{
      message: '昵称'
    },{
      message: '赏金'
    },{
      message: '关注'
    }],
    arrayLi:[{rank:'1',img:'http://tfwk.cn/image/photo1.png',name:'小希',money:'9791',follow:'关注'},
		      {rank:'2',img:'http://tfwk.cn/image/photo2.png',name:'小希',money:'9365',follow:'关注'},
		      {rank:'3',img:'http://tfwk.cn/image/photo3.png',name:'小希',money:'9002',follow:'关注'},
		      {rank:'4',img:'http://tfwk.cn/image/photo4.png',name:'小希',money:'7999',follow:'关注'},
		      {rank:'5',img:'http://tfwk.cn/image/photo5.png',name:'小希',money:'4672',follow:'关注'},
		      {rank:'6',img:'http://tfwk.cn/image/photo6.png',name:'小希',money:'4599',follow:'关注'},
		       {rank:'7',img:'http://tfwk.cn/image/photo7.png',name:'小希',money:'3022',follow:'关注'},
		        {rank:'8',img:'http://tfwk.cn/image/photo8.png',name:'小希',money:'1423',follow:'关注'},
		         {rank:'9',img:'http://tfwk.cn/image/photo9.png',name:'小希',money:'998',follow:'关注'},
		          {rank:'10',img:'http://tfwk.cn/image/photo10.png',name:'小希',money:'599',follow:'关注'}]
 }
})