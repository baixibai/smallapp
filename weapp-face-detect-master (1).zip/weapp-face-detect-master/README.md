# 微信小程序－人脸检测

### 说明：

实现人脸检测功能，包括年龄和性别。

### 数据接口:

- https://api.getweapp.com/vendor/face/detect

### 目录结构：

- pages — 存放项目页面文件
- utils — 存放日期格式化文件

### 开发环境：

微信web开发者工具 v0.11.112301

### 项目截图：

https://www.getweapp.com/project?projectId=58393cece8ff074c22472f2d
